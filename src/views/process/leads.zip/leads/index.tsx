import LeadsList from './LeadsList'

export default LeadsList
